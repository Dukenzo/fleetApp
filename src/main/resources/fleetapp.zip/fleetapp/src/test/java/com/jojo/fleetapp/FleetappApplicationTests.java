package com.jojo.fleetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FleetappApplicationTests {

	@Test
	void contextLoads() {
	}

}
